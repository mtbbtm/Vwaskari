"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Mic, MicOff, Plus, X, ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function NewRepairPage() {
  const router = useRouter()
  const [isListening, setIsListening] = useState(false)
  const [activeField, setActiveField] = useState<string | null>(null)
  const [speechSupported, setSpeechSupported] = useState(true)

  const [formData, setFormData] = useState({
    vehicle: "",
    customer: "",
    type: "",
    parts: [] as string[],
    newPart: "",
    laborCost: "",
    notes: "",
  })

  // Check if speech recognition is supported
  useEffect(() => {
    if (!("webkitSpeechRecognition" in window) && !("SpeechRecognition" in window)) {
      setSpeechSupported(false)
    }
  }, [])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  const handleSelectChange = (value: string, name: string) => {
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  const addPart = () => {
    if (formData.newPart.trim()) {
      setFormData({
        ...formData,
        parts: [...formData.parts, formData.newPart.trim()],
        newPart: "",
      })
    }
  }

  const removePart = (index: number) => {
    const updatedParts = [...formData.parts]
    updatedParts.splice(index, 1)
    setFormData({
      ...formData,
      parts: updatedParts,
    })
  }

  const toggleSpeechRecognition = (fieldName: string) => {
    if (!speechSupported) return

    if (isListening && activeField === fieldName) {
      // Stop listening
      setIsListening(false)
      setActiveField(null)
      // In a real app, you would stop the speech recognition here
    } else {
      // Start listening for the selected field
      setIsListening(true)
      setActiveField(fieldName)

      // Mock implementation of speech recognition
      // In a real app, you would use the Web Speech API
      const mockSpeechRecognition = () => {
        // Simulate speech recognition with a timeout
        setTimeout(() => {
          let recognizedText = ""

          // Generate mock text based on the field
          switch (fieldName) {
            case "vehicle":
              recognizedText = "Volkswagen Golf GTI"
              break
            case "customer":
              recognizedText = "Alex Johnson"
              break
            case "newPart":
              recognizedText = "Air filter"
              break
            case "laborCost":
              recognizedText = "85"
              break
            case "notes":
              recognizedText =
                "Customer reported strange noise when braking. Needs inspection of brake pads and rotors."
              break
            default:
              recognizedText = ""
          }

          // Update the form with the recognized text
          if (fieldName === "newPart") {
            setFormData({
              ...formData,
              newPart: recognizedText,
            })
          } else {
            setFormData({
              ...formData,
              [fieldName]: recognizedText,
            })
          }

          // Stop listening
          setIsListening(false)
          setActiveField(null)
        }, 2000) // Simulate 2 seconds of listening
      }

      mockSpeechRecognition()
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real app, you would save the repair data to a database
    console.log("Submitting repair:", formData)
    // Redirect to dashboard
    router.push("/dashboard")
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <header className="sticky top-0 z-10 bg-white border-b border-gray-200">
        <div className="container flex items-center h-16 px-4">
          <Link href="/dashboard" className="mr-4">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="w-5 h-5" />
              <span className="sr-only">Back</span>
            </Button>
          </Link>
          <h1 className="text-xl font-bold">New Repair</h1>
        </div>
      </header>

      <main className="flex-1 container px-4 py-6">
        <Card>
          <CardHeader>
            <CardTitle>Log New Repair</CardTitle>
            <CardDescription>Enter repair details or use speech-to-text for hands-free entry</CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-4">
              <Tabs defaultValue="details" className="space-y-4">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="details">Details</TabsTrigger>
                  <TabsTrigger value="parts">Parts & Labor</TabsTrigger>
                </TabsList>

                <TabsContent value="details" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="vehicle">Vehicle</Label>
                    <div className="flex space-x-2">
                      <Input
                        id="vehicle"
                        name="vehicle"
                        value={formData.vehicle}
                        onChange={handleInputChange}
                        className="flex-1"
                        placeholder="e.g., VW Golf GTI"
                        required
                      />
                      <Button
                        type="button"
                        variant={isListening && activeField === "vehicle" ? "default" : "outline"}
                        size="icon"
                        onClick={() => toggleSpeechRecognition("vehicle")}
                        disabled={!speechSupported}
                      >
                        {isListening && activeField === "vehicle" ? (
                          <MicOff className="w-4 h-4" />
                        ) : (
                          <Mic className="w-4 h-4" />
                        )}
                        <span className="sr-only">Use voice input</span>
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="customer">Customer Name</Label>
                    <div className="flex space-x-2">
                      <Input
                        id="customer"
                        name="customer"
                        value={formData.customer}
                        onChange={handleInputChange}
                        className="flex-1"
                        placeholder="e.g., John Smith"
                        required
                      />
                      <Button
                        type="button"
                        variant={isListening && activeField === "customer" ? "default" : "outline"}
                        size="icon"
                        onClick={() => toggleSpeechRecognition("customer")}
                        disabled={!speechSupported}
                      >
                        {isListening && activeField === "customer" ? (
                          <MicOff className="w-4 h-4" />
                        ) : (
                          <Mic className="w-4 h-4" />
                        )}
                        <span className="sr-only">Use voice input</span>
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="type">Repair Type</Label>
                    <Select
                      name="type"
                      value={formData.type}
                      onValueChange={(value) => handleSelectChange(value, "type")}
                      required
                    >
                      <SelectTrigger id="type">
                        <SelectValue placeholder="Select repair type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="engine">Engine</SelectItem>
                        <SelectItem value="brakes">Brakes</SelectItem>
                        <SelectItem value="electrical">Electrical</SelectItem>
                        <SelectItem value="suspension">Suspension</SelectItem>
                        <SelectItem value="transmission">Transmission</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="notes">Notes</Label>
                    <div className="flex space-x-2">
                      <Textarea
                        id="notes"
                        name="notes"
                        value={formData.notes}
                        onChange={handleInputChange}
                        className="flex-1"
                        placeholder="Additional notes about the repair"
                        rows={4}
                      />
                      <Button
                        type="button"
                        variant={isListening && activeField === "notes" ? "default" : "outline"}
                        size="icon"
                        onClick={() => toggleSpeechRecognition("notes")}
                        disabled={!speechSupported}
                      >
                        {isListening && activeField === "notes" ? (
                          <MicOff className="w-4 h-4" />
                        ) : (
                          <Mic className="w-4 h-4" />
                        )}
                        <span className="sr-only">Use voice input</span>
                      </Button>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="parts" className="space-y-4">
                  <div className="space-y-2">
                    <Label>Parts Used</Label>
                    <div className="flex space-x-2">
                      <Input
                        id="newPart"
                        name="newPart"
                        value={formData.newPart}
                        onChange={handleInputChange}
                        className="flex-1"
                        placeholder="Add a part"
                      />
                      <Button
                        type="button"
                        variant={isListening && activeField === "newPart" ? "default" : "outline"}
                        size="icon"
                        onClick={() => toggleSpeechRecognition("newPart")}
                        disabled={!speechSupported}
                      >
                        {isListening && activeField === "newPart" ? (
                          <MicOff className="w-4 h-4" />
                        ) : (
                          <Mic className="w-4 h-4" />
                        )}
                        <span className="sr-only">Use voice input</span>
                      </Button>
                      <Button type="button" variant="outline" onClick={addPart}>
                        <Plus className="w-4 h-4" />
                        <span className="sr-only">Add part</span>
                      </Button>
                    </div>

                    <div className="flex flex-wrap gap-2 mt-2">
                      {formData.parts.map((part, index) => (
                        <Badge key={index} variant="secondary" className="flex items-center gap-1">
                          {part}
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="h-4 w-4 p-0 hover:bg-transparent"
                            onClick={() => removePart(index)}
                          >
                            <X className="h-3 w-3" />
                            <span className="sr-only">Remove {part}</span>
                          </Button>
                        </Badge>
                      ))}
                      {formData.parts.length === 0 && (
                        <p className="text-sm text-muted-foreground">No parts added yet</p>
                      )}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="laborCost">Labor Cost ($)</Label>
                    <div className="flex space-x-2">
                      <Input
                        id="laborCost"
                        name="laborCost"
                        type="number"
                        value={formData.laborCost}
                        onChange={handleInputChange}
                        className="flex-1"
                        placeholder="e.g., 120"
                        min="0"
                        step="0.01"
                      />
                      <Button
                        type="button"
                        variant={isListening && activeField === "laborCost" ? "default" : "outline"}
                        size="icon"
                        onClick={() => toggleSpeechRecognition("laborCost")}
                        disabled={!speechSupported}
                      >
                        {isListening && activeField === "laborCost" ? (
                          <MicOff className="w-4 h-4" />
                        ) : (
                          <Mic className="w-4 h-4" />
                        )}
                        <span className="sr-only">Use voice input</span>
                      </Button>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
            <CardFooter>
              <Button type="submit" className="w-full">
                Save Repair
              </Button>
            </CardFooter>
          </form>
        </Card>
      </main>
    </div>
  )
}
