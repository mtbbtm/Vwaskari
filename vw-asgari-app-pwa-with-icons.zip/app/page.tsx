import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Car, Wrench, ClipboardList, Users } from "lucide-react"

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <header className="sticky top-0 z-10 bg-white border-b border-gray-200">
        <div className="container flex items-center justify-between h-16 px-4">
          <div className="flex items-center space-x-2">
            <Car className="w-6 h-6 text-gray-700" />
            <span className="text-xl font-bold">VW Asgari</span>
          </div>
          <Link href="/login">
            <Button variant="outline" size="sm">
              Login
            </Button>
          </Link>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-12 bg-gradient-to-b from-gray-100 to-white">
          <div className="container px-4 text-center">
            <h1 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
              Car Repair Workshop Management
            </h1>
            <p className="mt-4 text-lg text-gray-600">
              Streamline your workshop operations with our easy-to-use mobile app
            </p>
            <div className="mt-8">
              <Link href="/login">
                <Button size="lg" className="px-8">
                  Get Started
                </Button>
              </Link>
            </div>
          </div>
        </section>

        <section className="py-12">
          <div className="container px-4">
            <h2 className="mb-8 text-2xl font-bold text-center text-gray-900">Key Features</h2>
            <div className="grid gap-8 md:grid-cols-3">
              <div className="p-6 bg-white rounded-lg shadow-sm">
                <div className="flex items-center justify-center w-12 h-12 mb-4 bg-gray-100 rounded-full">
                  <ClipboardList className="w-6 h-6 text-gray-700" />
                </div>
                <h3 className="mb-2 text-lg font-medium">Repair Logging</h3>
                <p className="text-gray-600">Log repairs with parts, costs, notes, and repair types</p>
              </div>

              <div className="p-6 bg-white rounded-lg shadow-sm">
                <div className="flex items-center justify-center w-12 h-12 mb-4 bg-gray-100 rounded-full">
                  <Wrench className="w-6 h-6 text-gray-700" />
                </div>
                <h3 className="mb-2 text-lg font-medium">Speech-to-Text</h3>
                <p className="text-gray-600">Hands-free data entry for mechanics working on repairs</p>
              </div>

              <div className="p-6 bg-white rounded-lg shadow-sm">
                <div className="flex items-center justify-center w-12 h-12 mb-4 bg-gray-100 rounded-full">
                  <Users className="w-6 h-6 text-gray-700" />
                </div>
                <h3 className="mb-2 text-lg font-medium">User Roles</h3>
                <p className="text-gray-600">Different access levels for mechanics, managers, and admins</p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="py-6 bg-gray-800 text-gray-300">
        <div className="container px-4 text-center">
          <p>© {new Date().getFullYear()} VW Asgari Car Repair Workshop</p>
        </div>
      </footer>
    </div>
  )
}
