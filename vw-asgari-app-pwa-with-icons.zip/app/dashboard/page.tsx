"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Car, Plus, LogOut } from "lucide-react"
import { RepairCard } from "@/components/repair-card"
import { MobileNavbar } from "@/components/mobile-navbar"

// Mock data for repairs
const mockRepairs = [
  {
    id: "1",
    vehicle: "VW Golf GTI",
    customer: "John Smith",
    date: "2023-05-15",
    type: "Engine",
    status: "In Progress",
    parts: ["Oil Filter", "Engine Oil", "Spark Plugs"],
    laborCost: 120,
    notes: "Customer reported engine misfiring. Replacing spark plugs and performing oil change.",
  },
  {
    id: "2",
    vehicle: "VW Passat",
    customer: "Sarah Johnson",
    date: "2023-05-14",
    type: "Brakes",
    status: "Completed",
    parts: ["Brake Pads", "Brake Fluid"],
    laborCost: 90,
    notes: "Replaced front brake pads and flushed brake fluid.",
  },
  {
    id: "3",
    vehicle: "VW Tiguan",
    customer: "Michael Brown",
    date: "2023-05-16",
    type: "Electrical",
    status: "Scheduled",
    parts: [],
    laborCost: 0,
    notes: "Diagnostic for electrical issues with the infotainment system.",
  },
]

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <header className="sticky top-0 z-10 bg-white border-b border-gray-200">
        <div className="container flex items-center justify-between h-16 px-4">
          <div className="flex items-center space-x-2">
            <Car className="w-6 h-6 text-gray-700" />
            <span className="text-xl font-bold">VW Asgari</span>
          </div>
          <Link href="/">
            <Button variant="ghost" size="icon">
              <LogOut className="w-5 h-5" />
              <span className="sr-only">Logout</span>
            </Button>
          </Link>
        </div>
      </header>

      <main className="flex-1 container px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <Link href="/repairs/new">
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              New Repair
            </Button>
          </Link>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid w-full grid-cols-2 md:w-auto md:inline-flex">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="repairs">Repairs</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Active Repairs</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">3</div>
                  <p className="text-xs text-muted-foreground">+2 from yesterday</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Completed Today</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">5</div>
                  <p className="text-xs text-muted-foreground">+1 from yesterday</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Revenue Today</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">$1,240</div>
                  <p className="text-xs text-muted-foreground">+$340 from yesterday</p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Recent Repairs</CardTitle>
                <CardDescription>Overview of the most recent repair jobs</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockRepairs.map((repair) => (
                    <RepairCard key={repair.id} repair={repair} />
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="repairs" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>All Repairs</CardTitle>
                <CardDescription>Manage all repair jobs</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockRepairs.map((repair) => (
                    <RepairCard key={repair.id} repair={repair} />
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      <MobileNavbar activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  )
}
