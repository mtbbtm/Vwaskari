"use client"

import { Home, ClipboardList, Settings, Users } from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"

interface MobileNavbarProps {
  activeTab: string
  setActiveTab: (tab: string) => void
}

export function MobileNavbar({ activeTab, setActiveTab }: MobileNavbarProps) {
  const navItems = [
    {
      name: "Overview",
      icon: Home,
      href: "#overview",
      value: "overview",
    },
    {
      name: "Repairs",
      icon: ClipboardList,
      href: "#repairs",
      value: "repairs",
    },
    {
      name: "Team",
      icon: Users,
      href: "/team",
      value: "team",
    },
    {
      name: "Settings",
      icon: Settings,
      href: "/settings",
      value: "settings",
    },
  ]

  return (
    <div className="sticky bottom-0 z-10 bg-white border-t border-gray-200 md:hidden">
      <nav className="flex justify-around">
        {navItems.map((item) => {
          const isActive = activeTab === item.value

          // For tabs within the dashboard
          if (item.value === "overview" || item.value === "repairs") {
            return (
              <button
                key={item.name}
                className={cn(
                  "flex flex-col items-center py-2 px-3 text-xs",
                  isActive ? "text-primary" : "text-gray-500",
                )}
                onClick={() => setActiveTab(item.value)}
              >
                <item.icon className={cn("w-5 h-5 mb-1", isActive ? "text-primary" : "text-gray-500")} />
                {item.name}
              </button>
            )
          }

          // For links to other pages
          return (
            <Link
              key={item.name}
              href={item.href}
              className="flex flex-col items-center py-2 px-3 text-xs text-gray-500"
            >
              <item.icon className="w-5 h-5 mb-1 text-gray-500" />
              {item.name}
            </Link>
          )
        })}
      </nav>
    </div>
  )
}
