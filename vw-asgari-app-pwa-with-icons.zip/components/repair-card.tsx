import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ChevronRight } from "lucide-react"
import Link from "next/link"

interface Repair {
  id: string
  vehicle: string
  customer: string
  date: string
  type: string
  status: string
  parts: string[]
  laborCost: number
  notes: string
}

interface RepairCardProps {
  repair: Repair
}

export function RepairCard({ repair }: RepairCardProps) {
  // Function to determine badge color based on status
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "completed":
        return "bg-green-100 text-green-800"
      case "in progress":
        return "bg-blue-100 text-blue-800"
      case "scheduled":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  // Format date to be more readable
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = {
      year: "numeric",
      month: "short",
      day: "numeric",
    }
    return new Date(dateString).toLocaleDateString(undefined, options)
  }

  return (
    <Card className="overflow-hidden">
      <CardContent className="p-0">
        <div className="p-4">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-medium">{repair.vehicle}</h3>
            <Badge className={getStatusColor(repair.status)}>{repair.status}</Badge>
          </div>

          <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm mb-2">
            <div>
              <span className="text-muted-foreground">Customer:</span> {repair.customer}
            </div>
            <div>
              <span className="text-muted-foreground">Date:</span> {formatDate(repair.date)}
            </div>
            <div>
              <span className="text-muted-foreground">Type:</span> {repair.type}
            </div>
            <div>
              <span className="text-muted-foreground">Labor:</span> ${repair.laborCost}
            </div>
          </div>

          {repair.parts.length > 0 && (
            <div className="mb-2">
              <span className="text-sm text-muted-foreground">Parts:</span>
              <div className="flex flex-wrap gap-1 mt-1">
                {repair.parts.map((part, index) => (
                  <Badge key={index} variant="outline" className="text-xs">
                    {part}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {repair.notes && (
            <div className="text-sm">
              <span className="text-muted-foreground">Notes:</span>
              <p className="line-clamp-2">{repair.notes}</p>
            </div>
          )}
        </div>

        <div className="border-t border-gray-100 bg-gray-50 p-2 flex justify-end">
          <Link href={`/repairs/${repair.id}`}>
            <Button variant="ghost" size="sm" className="text-xs">
              View Details
              <ChevronRight className="ml-1 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  )
}
